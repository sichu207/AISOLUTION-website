// Set dynamic year(s) on footers by ID pattern
(function(){
  var year = new Date().getFullYear();
  var ids = ['year','year2','year3','year4','year5','year6','year7','year8','year9'];
  ids.forEach(function(id){
    var el = document.getElementById(id);
    if(el){ el.textContent = year; }
  });
})();


