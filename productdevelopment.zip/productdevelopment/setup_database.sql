-- Create database
CREATE DATABASE IF NOT EXISTS ai_solution;
USE ai_solution;

-- Create users table for admin login
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create contacts table for contact form submissions
CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    company VARCHAR(100),
    country VARCHAR(50),
    job_title VARCHAR(100),
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, password, email) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@ai-solution.com')
ON DUPLICATE KEY UPDATE username=username;

-- Insert sample contact data
INSERT INTO contacts (name, email, phone, company, country, job_title, message) VALUES 
('John Smith', 'john@example.com', '+44 123 456 7890', 'TechCorp Ltd', 'UK', 'IT Manager', 'Interested in your AI solutions for our company.'),
('Sarah Johnson', 'sarah@company.com', '+1 555 123 4567', 'Innovation Inc', 'USA', 'HR Director', 'Looking for AI-powered HR solutions.'),
('Michael Brown', 'mike@business.co.uk', '+44 987 654 3210', 'Business Solutions', 'UK', 'CEO', 'Need AI automation for our processes.')
ON DUPLICATE KEY UPDATE name=name;
