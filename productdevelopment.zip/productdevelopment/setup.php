<?php
// Database setup script
echo "<h2>AI-Solution Database Setup</h2>";

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ai_solution";

try {
    // Connect to MySQL server (without database)
    $conn = new mysqli($servername, $username, $password);
    
    if ($conn->connect_error) {
        die("❌ Connection failed: " . $conn->connect_error);
    }
    
    echo "✅ Connected to MySQL server<br>";
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS $dbname";
    if ($conn->query($sql) === TRUE) {
        echo "✅ Database '$dbname' created successfully<br>";
    } else {
        echo "❌ Error creating database: " . $conn->error . "<br>";
    }
    
    // Select the database
    $conn->select_db($dbname);
    
    // Create users table
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) === TRUE) {
        echo "✅ Users table created successfully<br>";
    } else {
        echo "❌ Error creating users table: " . $conn->error . "<br>";
    }
    
    // Create contacts table
    $sql = "CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20),
        company VARCHAR(100),
        country VARCHAR(50),
        job_title VARCHAR(100),
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) === TRUE) {
        echo "✅ Contacts table created successfully<br>";
    } else {
        echo "❌ Error creating contacts table: " . $conn->error . "<br>";
    }
    
    // Insert default admin user (password: admin123)
    $hashed_password = password_hash('admin123', PASSWORD_DEFAULT);
    $sql = "INSERT IGNORE INTO users (username, password, email) VALUES ('admin', '$hashed_password', 'admin@ai-solution.com')";
    
    if ($conn->query($sql) === TRUE) {
        echo "✅ Default admin user created (username: admin, password: admin123)<br>";
    } else {
        echo "❌ Error creating admin user: " . $conn->error . "<br>";
    }
    
    // Insert sample contact data
    $sql = "INSERT IGNORE INTO contacts (name, email, phone, company, country, job_title, message) VALUES 
        ('John Smith', 'john@example.com', '+44 123 456 7890', 'TechCorp Ltd', 'UK', 'IT Manager', 'Interested in your AI solutions for our company.'),
        ('Sarah Johnson', 'sarah@company.com', '+1 555 123 4567', 'Innovation Inc', 'USA', 'HR Director', 'Looking for AI-powered HR solutions.'),
        ('Michael Brown', 'mike@business.co.uk', '+44 987 654 3210', 'Business Solutions', 'UK', 'CEO', 'Need AI automation for our processes.')";
    
    if ($conn->query($sql) === TRUE) {
        echo "✅ Sample contact data inserted<br>";
    } else {
        echo "❌ Error inserting sample data: " . $conn->error . "<br>";
    }
    
    echo "<br><h3>🎉 Database setup completed successfully!</h3>";
    echo "<p><strong>Admin Login:</strong> username: admin, password: admin123</p>";
    echo "<p><a href='admin.html'>Go to Login Page</a> | <a href='index.html'>Go to Home</a></p>";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}

$conn->close();
?>
