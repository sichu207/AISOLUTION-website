<?php
$DB_HOST = '127.0.0.1:3307';  // use 3306 if your MySQL runs on default port
$DB_USER = "root";            // your DB username
$DB_PASS = "";                // your DB password (empty by default in XAMPP unless you set one)
$DB_NAME = "ai_solution";     // your database name

// Create connection
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Set charset to utf8
$conn->set_charset("utf8");
?>
