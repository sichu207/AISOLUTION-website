<?php
// generate_hash.php — run once, then delete
$password = 'Admin@123'; // change this to your desired admin password BEFORE running
echo "Password (plaintext): " . htmlspecialchars($password) . "<br><br>";
echo "Use this hash in your SQL insert:<br><pre>" . password_hash($password, PASSWORD_DEFAULT) . "</pre>";
?>
