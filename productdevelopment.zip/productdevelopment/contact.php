<?php
// contact.php
require_once 'db.php';

function clean($s){ return trim($s); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: contact.html');
    exit;
}

$name = clean($_POST['name'] ?? '');
$email = clean($_POST['email'] ?? '');
$phone = clean($_POST['phone'] ?? '');
$company = clean($_POST['company'] ?? '');
$country = clean($_POST['country'] ?? '');
$job_title = clean($_POST['job_title'] ?? '');
$message = clean($_POST['message'] ?? '');

$errors = [];
if (!$name) $errors[] = "Name is required.";
if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Valid email is required.";
if (!$message) $errors[] = "Message is required.";

if (!empty($errors)) {
    // send back as query string (simple). For production use session/flash.
    $qs = http_build_query(['error' => implode(' | ', $errors)]);
    header('Location: contact.html?' . $qs);
    exit;
}

$stmt = $conn->prepare("INSERT INTO contacts (name,email,phone,company,country,job_title,message) VALUES (?, ?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param('sssssss', $name, $email, $phone, $company, $country, $job_title, $message);
$ok = $stmt->execute();
if ($ok) {
    header('Location: contact.html?success=1');
    exit;
} else {
    header('Location: contact.html?error=' . urlencode("DB error: " . $stmt->error));
    exit;
}
